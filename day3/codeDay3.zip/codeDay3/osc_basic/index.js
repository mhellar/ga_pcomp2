var osc = require('node-osc');
 
var oscServer = new osc.Server(8080, '0.0.0.0');
 
oscServer.on('message', function (msg) {
  console.log(`Message: ${msg}`);
});
